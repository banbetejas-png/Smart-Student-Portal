# Smart Student Portal

Smart Student Portal helps students and faculty manage attendance, academics,
fees, assignments, notices, tasks, and profile details in one place.

## Open in VS Code

Open the project root (the folder containing `pnpm-workspace.yaml`) in VS Code.
The portal lives at `artifacts/smart-student-portal`.

### Requirements

- Node.js 20 or newer
- pnpm 9 or newer
- A Supabase project with the portal tables and authentication enabled

### Setup

1. Install dependencies from the project root:

   ```bash
   pnpm install
   ```

2. Copy the environment template:

   ```bash
   cp artifacts/smart-student-portal/.env.example artifacts/smart-student-portal/.env
   ```

3. Fill in the Supabase values in `artifacts/smart-student-portal/.env`.

4. Start the portal:

   ```bash
   pnpm --filter @workspace/smart-student-portal run dev
   ```

The development server uses the `PORT` and `BASE_PATH` values supplied by the
project workflow. For a direct VS Code terminal run, use:

```bash
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/smart-student-portal run dev
```

## Useful commands

```bash
pnpm --filter @workspace/smart-student-portal run typecheck
pnpm --filter @workspace/smart-student-portal run build
```

## Main features

- Student and faculty signup/login with Supabase authentication
- Email confirmation and password reset
- Protected student and faculty workspaces
- Attendance, timetable, subjects, academics, fees, assignments, notices, and tasks
- Profile editing for personal academic details
- Installable PWA support

## Project map

- `src/routes/` — application pages
- `src/components/` — shared student and faculty shells
- `src/lib/store.ts` — local student workspace state
- `src/lib/cloud.ts` — Supabase account and session helpers
- `src/integrations/supabase/` — Supabase client and generated database types
- `public/` — app icons and static assets