import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  Eye,
  EyeOff,
  GraduationCap,
  LockKeyhole,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { setState } from "@/lib/store";
import { savePendingAccount } from "@/lib/cloud";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/signup")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Create Account — Smart Student Portal" },
      {
        name: "description",
        content: "Register as a student or faculty member to start using the portal.",
      },
      { property: "og:title", content: "Create Account — Smart Student Portal" },
      {
        property: "og:description",
        content: "Register as a student or faculty member.",
      },
    ],
  }),
  component: SignupPage,
});

const field =
  "w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none placeholder:text-muted-foreground transition-[border-color,box-shadow] focus:border-sky focus:ring-4 focus:ring-sky/15";

function SignupPage() {
  const navigate = useNavigate();
  const [role, setRole] = useState<"student" | "teacher">("student");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [confirmationEmail, setConfirmationEmail] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [form, setForm] = useState({
    fullName: "",
    studentId: "",
    email: "",
    branch: "",
    year: "",
    semester: "",
    password: "",
    confirmPassword: "",
  });

  const set =
    (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setConfirmationEmail("");

    if (form.password.length < 6) {
      setError("Use at least 6 characters for your password.");
      return;
    }
    if (form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setBusy(true);

    const email = form.email.trim().toLowerCase();
    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password: form.password,
      options: {
        emailRedirectTo: `${window.location.origin}/login`,
        data: {
          full_name: form.fullName.trim(),
          role,
          roll_no: role === "student" ? form.studentId.trim() : null,
          branch: form.branch.trim(),
          semester: role === "student" ? Number(String(form.semester).replace(/\D/g, "")) || null : null,
        },
      },
    });

    if (signUpError || !data.user) {
      setBusy(false);
      setError(signUpError?.message ?? "Could not create the account.");
      return;
    }

    // Supabase projects with email confirmation enabled return a user without a session.
    // Keep the user on this screen until their account is verified.
    if (!data.session) {
      savePendingAccount({
        role,
        fullName: form.fullName,
        studentId: form.studentId,
        email,
        branch: form.branch,
        year: form.year,
        semester: form.semester,
      });
      setBusy(false);
      setConfirmationEmail(email);
      return;
    }

    const semester = Number(String(form.semester).replace(/\D/g, "")) || null;
    const [{ error: profileError }, { error: roleError }] = await Promise.all([
      supabase.from("profiles").insert({
        id: data.user.id,
        email,
        full_name: form.fullName.trim(),
        roll_no: role === "student" ? form.studentId.trim() : null,
        branch: form.branch.trim() || null,
        semester: role === "student" ? semester : null,
      }),
      supabase.from("user_roles").insert({ user_id: data.user.id, role }),
    ]);

    setBusy(false);

    if (profileError || roleError) {
      setError("Your account was created, but we could not finish your portal profile. Please sign in and try again.");
      return;
    }

    if (role === "teacher") {
      navigate({ to: "/teacher/dashboard" });
      return;
    }
    const { confirmPassword: _confirmPassword, ...studentForm } = form;
    setState((s) => ({ ...s, student: studentForm, loggedIn: true }));
    navigate({ to: "/dashboard" });
  }

  if (confirmationEmail) {
    return (
      <main className="auth-canvas relative flex min-h-[100dvh] items-center overflow-hidden px-4 py-6 sm:px-6 lg:px-10">
        <div className="auth-grid pointer-events-none absolute inset-0" aria-hidden="true" />
        <section className="relative mx-auto w-full max-w-lg rounded-[2rem] border border-border/70 bg-card/95 p-7 text-center auth-card-shadow sm:p-12">
          <div className="mx-auto grid h-16 w-16 place-items-center rounded-3xl bg-teal/12 text-teal">
            <CheckCircle2 className="h-8 w-8" />
          </div>
          <p className="mt-7 text-xs font-bold uppercase tracking-[0.18em] text-sky">One last step</p>
          <h1 className="mt-2 text-3xl font-extrabold tracking-[-0.04em] text-navy">Check your inbox</h1>
          <p data-testid="status-signup-confirmation" className="mx-auto mt-4 max-w-sm text-sm leading-6 text-muted-foreground">
            We sent a confirmation link to <span className="font-bold text-navy">{confirmationEmail}</span>. Verify your email, then come back to sign in.
          </p>
          <div className="mt-8 rounded-2xl bg-secondary/70 p-4 text-left">
            <div className="flex gap-3">
              <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-teal" />
              <p className="text-xs leading-5 text-muted-foreground">
                If you do not see it soon, check your spam folder. The link will return you to the portal sign-in.
              </p>
            </div>
          </div>
          <Link
            data-testid="link-confirmation-login"
            to="/login"
            className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-3.5 text-sm font-bold text-primary-foreground transition-[transform,opacity] hover:-translate-y-0.5 hover:opacity-95"
          >
            Continue to sign in
            <ArrowRight className="h-4 w-4" />
          </Link>
        </section>
      </main>
    );
  }

  return (
    <main className="auth-canvas relative flex min-h-[100dvh] items-center overflow-hidden px-4 py-6 sm:px-6 lg:px-10">
      <div className="auth-grid pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="relative mx-auto grid w-full max-w-5xl overflow-hidden rounded-[2rem] border border-border/70 bg-card/90 auth-card-shadow backdrop-blur md:min-h-[700px] md:grid-cols-[0.84fr_1.16fr]">
        <aside className="auth-panel relative hidden overflow-hidden p-9 text-primary-foreground md:flex md:flex-col">
          <div className="relative flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/12 ring-1 ring-white/20">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-extrabold tracking-tight">Smart Student</p>
              <p className="text-[11px] text-white/60">Portal</p>
            </div>
          </div>
          <div className="relative mt-auto">
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.2em] text-teal">Start with the basics</p>
            <h1 className="max-w-sm text-4xl font-extrabold leading-[1.06] tracking-[-0.04em]">
              Your academic workspace, ready when you are.
            </h1>
            <p className="mt-5 max-w-sm text-sm leading-6 text-white/70">
              Create one account for the student or faculty tools you use throughout the semester.
            </p>
            <div className="mt-9 space-y-3 text-xs text-white/75">
              {["Attendance and timetable at a glance", "Assignments, notices, and tasks together", "A secure account for your campus life"].map((item) => (
                <div key={item} className="flex items-center gap-2.5">
                  <span className="grid h-5 w-5 place-items-center rounded-full bg-teal/20 text-teal">
                    <Check className="h-3 w-3" />
                  </span>
                  {item}
                </div>
              ))}
            </div>
          </div>
        </aside>

        <section className="px-6 py-8 sm:px-10 sm:py-10">
          <div className="mb-7 flex items-center justify-between gap-4">
            <Link data-testid="link-back-login" to="/login" className="inline-flex items-center gap-1.5 text-xs font-bold text-muted-foreground hover:text-navy">
              <ArrowLeft className="h-3.5 w-3.5" />
              Back to sign in
            </Link>
            <div className="flex items-center gap-1.5 text-[11px] font-semibold text-muted-foreground">
              <span className="h-1.5 w-1.5 rounded-full bg-sky" />
              Step 1 of 1
            </div>
          </div>
          <div className="mb-7">
            <div className="mb-3 grid h-10 w-10 place-items-center rounded-2xl bg-navy text-primary-foreground md:hidden">
              <GraduationCap className="h-5 w-5" />
            </div>
            <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-sky">Create your account</p>
            <h2 className="text-3xl font-extrabold tracking-[-0.04em] text-navy sm:text-4xl">Let’s get you set up</h2>
            <p className="mt-2 text-sm leading-6 text-muted-foreground">Use your campus details so the portal can show the right workspace.</p>
          </div>

          <div className="mb-5 grid grid-cols-2 gap-2 rounded-2xl bg-secondary/75 p-1.5">
            {(["student", "teacher"] as const).map((r) => {
              const selected = role === r;
              return (
                <button
                  data-testid={`button-role-${r}`}
                  key={r}
                  type="button"
                  onClick={() => setRole(r)}
                  className={`flex items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-bold transition-[background-color,color,box-shadow] ${
                    selected ? "bg-card text-navy shadow-sm" : "text-muted-foreground hover:text-navy"
                  }`}
                >
                  {r === "teacher" ? <ShieldCheck className="h-4 w-4" /> : <UserRound className="h-4 w-4" />}
                  {r === "teacher" ? "Faculty" : "Student"}
                </button>
              );
            })}
          </div>

          <form onSubmit={submit} className="space-y-3.5">
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block space-y-1.5">
                <span className="text-xs font-bold text-navy">Full name</span>
                <input data-testid="input-full-name" className={field} placeholder="Your name" value={form.fullName} onChange={set("fullName")} required autoComplete="name" />
              </label>
              {role === "student" ? (
                <label className="block space-y-1.5">
                  <span className="text-xs font-bold text-navy">Student ID</span>
                  <input data-testid="input-student-id" className={field} placeholder="e.g. STU-2048" value={form.studentId} onChange={set("studentId")} required />
                </label>
              ) : null}
            </div>
            <label className="block space-y-1.5">
              <span className="text-xs font-bold text-navy">Email address</span>
              <input data-testid="input-signup-email" className={field} type="email" placeholder="you@campus.edu" value={form.email} onChange={set("email")} required autoComplete="email" />
            </label>
            <label className="block space-y-1.5">
              <span className="text-xs font-bold text-navy">{role === "student" ? "Branch" : "Department"}</span>
              <input data-testid="input-branch" className={field} placeholder={role === "student" ? "e.g. Computer Science" : "e.g. Computer Engineering"} value={form.branch} onChange={set("branch")} required />
            </label>
            {role === "student" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <label className="block space-y-1.5">
                  <span className="text-xs font-bold text-navy">Year</span>
                  <select data-testid="select-year" className={field} value={form.year} onChange={set("year")} required>
                    <option value="">Select year</option>
                    {["First Year", "Second Year", "Third Year", "Final Year"].map((y) => (
                      <option key={y}>{y}</option>
                    ))}
                  </select>
                </label>
                <label className="block space-y-1.5">
                  <span className="text-xs font-bold text-navy">Semester</span>
                  <select data-testid="select-semester" className={field} value={form.semester} onChange={set("semester")} required>
                    <option value="">Select semester</option>
                    {Array.from({ length: 8 }, (_, i) => `Semester ${i + 1}`).map((s) => (
                      <option key={s}>{s}</option>
                    ))}
                  </select>
                </label>
              </div>
            ) : null}
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="block space-y-1.5">
                <span className="text-xs font-bold text-navy">Password</span>
                <span className="relative block">
                  <input data-testid="input-signup-password" className={`${field} pr-12`} type={showPassword ? "text" : "password"} placeholder="At least 6 characters" value={form.password} onChange={set("password")} required minLength={6} autoComplete="new-password" />
                  <button data-testid="button-toggle-signup-password" type="button" aria-label={showPassword ? "Hide password" : "Show password"} onClick={() => setShowPassword((visible) => !visible)} className="absolute top-1/2 right-3 grid -translate-y-1/2 place-items-center rounded-lg p-1.5 text-muted-foreground hover:bg-secondary hover:text-navy">
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </span>
              </label>
              <label className="block space-y-1.5">
                <span className="text-xs font-bold text-navy">Confirm password</span>
                <input data-testid="input-confirm-password" className={field} type={showPassword ? "text" : "password"} placeholder="Repeat your password" value={form.confirmPassword} onChange={set("confirmPassword")} required minLength={6} autoComplete="new-password" />
              </label>
            </div>
            {error ? (
              <p data-testid="status-signup-error" role="alert" className="rounded-xl border border-destructive/20 bg-destructive/8 px-3 py-2.5 text-xs font-semibold leading-5 text-destructive">
                {error}
              </p>
            ) : null}
            <button
              data-testid="button-submit-signup"
              type="submit"
              disabled={busy}
              className="group flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-3.5 text-sm font-bold text-primary-foreground shadow-lg shadow-navy/15 transition-[transform,opacity] hover:-translate-y-0.5 hover:opacity-95 disabled:pointer-events-none disabled:opacity-60"
            >
              {busy ? "Creating your account…" : "Create account"}
              {!busy ? <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /> : null}
            </button>
            <p className="text-center text-xs text-muted-foreground">
              Already have an account?{" "}
              <Link data-testid="link-login" to="/login" className="font-bold text-navy hover:text-sky">
                Sign in
              </Link>
            </p>
          </form>
          <div className="mt-6 flex items-center justify-center gap-2 text-[11px] text-muted-foreground">
            <LockKeyhole className="h-3.5 w-3.5 text-teal" />
            <span>Your details are handled through secure authentication.</span>
          </div>
        </section>
      </div>
    </main>
  );
}
