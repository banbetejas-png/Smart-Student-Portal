import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Edit3, LogOut, Save, User, X } from "lucide-react";
import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { overallAttendance, setState, useAppState } from "@/lib/store";
import { clearSession } from "@/lib/auth";
import { signOutEverywhere, useAuth } from "@/lib/cloud";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/profile")({
  head: () => ({
    meta: [
      { title: "Profile — Smart Student Portal" },
      {
        name: "description",
        content: "View your student details, app preferences and sign out of the portal.",
      },
      { property: "og:title", content: "Profile — Smart Student Portal" },
      { property: "og:description", content: "Student details, preferences and logout." },
    ],
  }),
  component: ProfilePage,
});

function ProfilePage() {
  const state = useAppState();
  const navigate = useNavigate();
  const s = state.student;
  const { userId } = useAuth();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [form, setForm] = useState({
    fullName: "",
    studentId: "",
    branch: "",
    year: "",
    semester: "",
  });

  useEffect(() => {
    setForm({
      fullName: s?.fullName ?? "",
      studentId: s?.studentId ?? "",
      branch: s?.branch ?? "",
      year: s?.year ?? "",
      semester: s?.semester?.startsWith("Semester ") ? s.semester : s?.semester ? `Semester ${s.semester}` : "",
    });
  }, [s]);

  const updateForm = (key: keyof typeof form, value: string) => {
    setForm((current) => ({ ...current, [key]: value }));
    setMessage("");
  };

  async function saveProfile(e: React.FormEvent) {
    e.preventDefault();
    if (!userId || !s) return;

    setSaving(true);
    setMessage("");
    const semester = Number(form.semester.replace(/\D/g, "")) || null;
    const { error } = await supabase
      .from("profiles")
      .update({
        full_name: form.fullName.trim(),
        roll_no: form.studentId.trim() || null,
        branch: form.branch.trim() || null,
        semester,
      })
      .eq("id", userId);

    setSaving(false);
    if (error) {
      setMessage("We could not save your profile. Please try again.");
      return;
    }

    setState((current) => ({
      ...current,
      student: current.student
        ? {
            ...current.student,
            fullName: form.fullName.trim(),
            studentId: form.studentId.trim(),
            branch: form.branch.trim(),
            year: form.year,
            semester: form.semester,
          }
        : current.student,
    }));
    setEditing(false);
    setMessage("Profile updated.");
  }

  const rows = [
    ["Full Name", s?.fullName],
    ["Student ID", s?.studentId],
    ["Email", s?.email],
    ["Branch", s?.branch],
    ["Year", s?.year],
    ["Semester", s?.semester],
  ] as const;

  return (
    <AppShell title="Profile">
      <section className="flex items-center gap-3 rounded-2xl bg-navy p-4 text-primary-foreground">
        <div className="grid h-14 w-14 shrink-0 place-items-center rounded-full bg-white/15">
          <User className="h-7 w-7" />
        </div>
        <div className="min-w-0">
          <p className="truncate text-base font-extrabold">{s?.fullName ?? "Guest Student"}</p>
          <p className="truncate text-xs text-white/70">{s?.email ?? "Not signed in"}</p>
          <p className="mt-1 text-[11px] font-semibold text-teal">
            {overallAttendance(state)}% overall attendance
          </p>
        </div>
      </section>

      <section className="mt-4 divide-y divide-border rounded-2xl bg-card px-4 shadow-sm">
        {rows.map(([label, value]) => (
          <div key={label} className="grid grid-cols-[minmax(0,1fr)_auto] gap-3 py-3">
            <span className="text-xs text-muted-foreground">{label}</span>
            <span className="truncate text-xs font-semibold text-navy">{value || "—"}</span>
          </div>
        ))}
      </section>

      <section className="mt-4 rounded-2xl bg-card p-4 shadow-sm">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-navy">Personal details</h3>
            <p className="mt-1 text-xs text-muted-foreground">
              Keep your academic information up to date.
            </p>
          </div>
          {!editing ? (
            <button
              type="button"
              onClick={() => {
                setEditing(true);
                setMessage("");
              }}
              className="inline-flex items-center gap-1.5 rounded-xl bg-secondary px-3 py-2 text-xs font-bold text-navy"
            >
              <Edit3 className="h-3.5 w-3.5" /> Edit
            </button>
          ) : null}
        </div>

        {editing ? (
          <form onSubmit={saveProfile} className="mt-4 space-y-3">
            <input
              className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-xs outline-none focus:border-sky focus:ring-2 focus:ring-sky/20"
              placeholder="Full name"
              value={form.fullName}
              onChange={(e) => updateForm("fullName", e.target.value)}
              required
            />
            <input
              className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-xs outline-none focus:border-sky focus:ring-2 focus:ring-sky/20"
              placeholder="Student ID"
              value={form.studentId}
              onChange={(e) => updateForm("studentId", e.target.value)}
              required
            />
            <input
              className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-xs outline-none focus:border-sky focus:ring-2 focus:ring-sky/20"
              placeholder="Branch"
              value={form.branch}
              onChange={(e) => updateForm("branch", e.target.value)}
              required
            />
            <div className="grid grid-cols-2 gap-2">
              <select
                className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-xs outline-none focus:border-sky focus:ring-2 focus:ring-sky/20"
                value={form.year}
                onChange={(e) => updateForm("year", e.target.value)}
                required
              >
                <option value="">Year</option>
                {["First Year", "Second Year", "Third Year", "Final Year"].map((year) => (
                  <option key={year}>{year}</option>
                ))}
              </select>
              <select
                className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-xs outline-none focus:border-sky focus:ring-2 focus:ring-sky/20"
                value={form.semester}
                onChange={(e) => updateForm("semester", e.target.value)}
                required
              >
                <option value="">Semester</option>
                {Array.from({ length: 8 }, (_, index) => `Semester ${index + 1}`).map((semester) => (
                  <option key={semester}>{semester}</option>
                ))}
              </select>
            </div>
            {message ? (
              <p
                className={`text-xs font-semibold ${
                  message === "Profile updated." ? "text-teal" : "text-destructive"
                }`}
              >
                {message}
              </p>
            ) : null}
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-navy py-2.5 text-xs font-bold text-primary-foreground disabled:opacity-60"
              >
                <Save className="h-3.5 w-3.5" /> {saving ? "Saving…" : "Save changes"}
              </button>
              <button
                type="button"
                onClick={() => {
                  setEditing(false);
                  setMessage("");
                }}
                className="inline-flex items-center justify-center gap-1.5 rounded-xl bg-secondary px-3 py-2.5 text-xs font-bold text-navy"
              >
                <X className="h-3.5 w-3.5" /> Cancel
              </button>
            </div>
          </form>
        ) : message ? (
          <p className="mt-3 text-xs font-semibold text-teal">{message}</p>
        ) : null}
      </section>

      <section className="mt-4 rounded-2xl bg-card p-4 shadow-sm">
        <h3 className="text-sm font-bold text-navy">App Preferences</h3>
        <ul className="mt-2 space-y-2 text-xs text-muted-foreground">
          <li className="flex justify-between">
            <span>Deadline reminders</span>
            <span className="font-semibold text-teal">On</span>
          </li>
          <li className="flex justify-between">
            <span>Attendance target</span>
            <span className="font-semibold text-navy">75%</span>
          </li>
          <li className="flex justify-between">
            <span>Data storage</span>
            <span className="font-semibold text-navy">This device</span>
          </li>
        </ul>
      </section>

      <section className="mt-4 rounded-2xl bg-card p-4 shadow-sm">
        <h3 className="text-sm font-bold text-navy">About Us</h3>
        <p className="mt-1 text-xs font-semibold text-sky">Developed by ATMS</p>
        <ul className="mt-2 space-y-1 text-xs text-muted-foreground">
          {["Tejas Banbe", "Atharva Bahulekar", "Mayur Bhoi", "Soham Bendal"].map((n) => (
            <li key={n}>• {n}</li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-muted-foreground">
          Smart Student Portal • Version 1.0 (NEP Compliant)
        </p>
      </section>

      <button
        onClick={async () => {
          clearSession();
          await signOutEverywhere();
          setState((prev) => ({ ...prev, loggedIn: false }));
          navigate({ to: "/login", replace: true });
        }}
        className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-destructive py-3.5 text-sm font-bold text-destructive-foreground"
      >
        <LogOut className="h-4 w-4" /> Logout
      </button>
    </AppShell>
  );
}
