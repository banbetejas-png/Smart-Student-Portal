import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, CheckCircle2, Eye, EyeOff, GraduationCap, KeyRound, LockKeyhole, ShieldCheck } from "lucide-react";
import { setState } from "@/lib/store";
import { supabase } from "@/integrations/supabase/client";
import { finishPendingAccount, loadAccount } from "@/lib/cloud";

export const Route = createFileRoute("/login")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Login — Smart Student Portal" },
      { name: "description", content: "Sign in to your Smart Student Portal account." },
      { property: "og:title", content: "Login — Smart Student Portal" },
      { property: "og:description", content: "Sign in to your student portal account." },
    ],
  }),
  component: LoginPage,
});

const field =
  "w-full rounded-xl border border-border bg-card px-4 py-3 text-sm outline-none placeholder:text-muted-foreground transition-[border-color,box-shadow] focus:border-sky focus:ring-4 focus:ring-sky/15";

function LoginPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [resetMode, setResetMode] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setNotice("");
    setBusy(true);

    const normalizedEmail = email.trim().toLowerCase();
    if (resetMode) {
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(normalizedEmail, {
        redirectTo: `${window.location.origin}/login`,
      });
      setBusy(false);
      if (resetError) {
        setError(resetError.message);
        return;
      }
      setNotice("If an account exists for this email, a password reset link is on its way.");
      return;
    }

    const { data, error: signInError } = await supabase.auth.signInWithPassword({
      email: normalizedEmail,
      password,
    });

    if (data?.user && !signInError) {
      let pending = null;
      try {
        pending = await finishPendingAccount(data.user.id, normalizedEmail);
      } catch (accountError) {
        setBusy(false);
        setError(accountError instanceof Error ? accountError.message : "We could not finish setting up your account.");
        return;
      }
      const account = await loadAccount(data.user.id);
      setBusy(false);
      const role = account.role ?? pending?.role;
      if (role === "teacher") {
        navigate({ to: "/teacher/dashboard" });
      } else if (role === "student") {
        setState((s) => ({
          ...s,
          loggedIn: true,
          student: {
            fullName: account.profile?.full_name ?? pending?.fullName ?? "",
            studentId: account.profile?.roll_no ?? pending?.studentId ?? "",
            email: account.profile?.email ?? data.user.email ?? normalizedEmail,
            branch: account.profile?.branch ?? pending?.branch ?? "",
            year: pending?.year ?? s.student?.year ?? "",
            semester: account.profile?.semester
              ? `Semester ${account.profile.semester}`
              : pending?.semester ?? s.student?.semester ?? "",
            password: "",
          },
        }));
        navigate({ to: "/dashboard" });
      } else {
        setError("Your account is missing a portal role. Please contact an administrator.");
      }
      return;
    }

    setBusy(false);
    setError(signInError?.message ?? "Incorrect email or password. Check your details and try again.");
  }

  return (
    <main className="auth-canvas relative flex min-h-[100dvh] items-center overflow-hidden px-4 py-6 sm:px-6 lg:px-10">
      <div className="auth-grid pointer-events-none absolute inset-0" aria-hidden="true" />
      <div className="relative mx-auto grid w-full max-w-5xl overflow-hidden rounded-[2rem] border border-border/70 bg-card/90 auth-card-shadow backdrop-blur md:min-h-[650px] md:grid-cols-[0.92fr_1.08fr]">
        <aside className="auth-panel relative hidden overflow-hidden p-9 text-primary-foreground md:flex md:flex-col">
          <div className="absolute -right-16 top-20 h-44 w-44 rounded-full border border-white/15" aria-hidden="true" />
          <div className="absolute -right-7 top-29 h-28 w-28 rounded-full border border-white/10" aria-hidden="true" />
          <div className="relative flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white/12 ring-1 ring-white/20">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-extrabold tracking-tight">Smart Student</p>
              <p className="text-[11px] text-white/60">Portal</p>
            </div>
          </div>
          <div className="relative mt-auto">
            <p className="mb-4 text-xs font-bold uppercase tracking-[0.2em] text-teal">Your campus, in focus</p>
            <h1 className="max-w-sm text-4xl font-extrabold leading-[1.06] tracking-[-0.04em]">
              A clearer way to stay on track.
            </h1>
            <p className="mt-5 max-w-sm text-sm leading-6 text-white/70">
              Keep attendance, assignments, notices, and your next important date in one calm workspace.
            </p>
            <div className="auth-float mt-9 grid max-w-sm grid-cols-2 gap-3">
              <div className="rounded-2xl border border-white/10 bg-white/8 p-4">
                <ShieldCheck className="h-5 w-5 text-teal" />
                <p className="mt-3 text-xs font-semibold">Private by design</p>
                <p className="mt-1 text-[11px] leading-4 text-white/55">Secure access for your campus account.</p>
              </div>
              <div className="rounded-2xl border border-white/10 bg-white/8 p-4">
                <KeyRound className="h-5 w-5 text-sky" />
                <p className="mt-3 text-xs font-semibold">One place to begin</p>
                <p className="mt-1 text-[11px] leading-4 text-white/55">Your day starts with the right context.</p>
              </div>
            </div>
          </div>
        </aside>

        <section className="flex flex-col justify-center px-6 py-8 sm:px-10 sm:py-12">
          <div className="mb-8 flex items-center gap-3 md:hidden">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-navy text-primary-foreground">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-extrabold text-navy">Smart Student</p>
              <p className="text-[11px] text-muted-foreground">Portal</p>
            </div>
          </div>
          <div className="mb-7">
            <p className="mb-2 text-xs font-bold uppercase tracking-[0.18em] text-sky">Portal access</p>
            <h2 className="text-3xl font-extrabold tracking-[-0.04em] text-navy sm:text-4xl">
              {resetMode ? "Reset your password" : "Welcome back"}
            </h2>
            <p className="mt-2 max-w-md text-sm leading-6 text-muted-foreground">
              {resetMode
                ? "Enter your account email and we’ll send a secure link to get you back in."
                : "Sign in to pick up where your academic day left off."}
            </p>
          </div>

          {notice ? (
            <div data-testid="status-login-notice" className="mb-5 flex gap-3 rounded-2xl border border-teal/25 bg-teal/10 p-3.5 text-xs leading-5 text-navy">
              <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-teal" />
              <span>{notice}</span>
            </div>
          ) : null}

          <form onSubmit={submit} className="space-y-4">
            <label className="block space-y-1.5">
              <span className="text-xs font-bold text-navy">Email address</span>
              <input
                data-testid="input-email"
                className={field}
                type="email"
                autoComplete="email"
                placeholder="you@campus.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </label>
            {!resetMode ? (
              <label className="block space-y-1.5">
                <span className="text-xs font-bold text-navy">Password</span>
                <span className="relative block">
                  <input
                    data-testid="input-password"
                    className={`${field} pr-12`}
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                  <button
                    data-testid="button-toggle-password"
                    type="button"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                    onClick={() => setShowPassword((visible) => !visible)}
                    className="absolute top-1/2 right-3 grid -translate-y-1/2 place-items-center rounded-lg p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-navy"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </span>
              </label>
            ) : null}
            {error ? (
              <p data-testid="status-login-error" role="alert" className="rounded-xl border border-destructive/20 bg-destructive/8 px-3 py-2.5 text-xs font-semibold leading-5 text-destructive">
                {error}
              </p>
            ) : null}
            <button
              data-testid="button-submit-login"
              type="submit"
              disabled={busy}
              className="group flex w-full items-center justify-center gap-2 rounded-xl bg-navy py-3.5 text-sm font-bold text-primary-foreground shadow-lg shadow-navy/15 transition-[transform,opacity] hover:-translate-y-0.5 hover:opacity-95 disabled:pointer-events-none disabled:opacity-60"
            >
              {busy ? "Please wait…" : resetMode ? "Send reset link" : "Sign in"}
              {!busy ? <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" /> : null}
            </button>
            <div className="flex items-center justify-between gap-3 text-xs">
              <button
                data-testid="button-forgot-password"
                type="button"
                onClick={() => {
                  setResetMode((mode) => !mode);
                  setError("");
                  setNotice("");
                }}
                className="font-semibold text-sky hover:underline"
              >
                {resetMode ? "Back to sign in" : "Forgot password?"}
              </button>
              <span className="text-muted-foreground">
                New here?{" "}
                <Link data-testid="link-signup" to="/signup" className="font-bold text-navy hover:text-sky">
                  Create account
                </Link>
              </span>
            </div>
          </form>

          <div className="mt-9 flex items-center gap-2 text-[11px] text-muted-foreground">
            <LockKeyhole className="h-3.5 w-3.5 text-teal" />
            <span>Your sign-in is protected by Supabase authentication.</span>
          </div>
        </section>
      </div>
    </main>
  );
}
